leaves = struct('number','6','name','neem','leaftype','compound','venation','pinnate','texture','slightly waxy','margin','smoother','shape','7lanceolate');
neem = imread("C:\Users\user\Desktop\group 2\IMG_20260914_140354_583.jpg");
figure;
imshow(neem);





