Leaves = struct('number','4','name','lantana','leaftype','simple','venation','pinate','texture','roughly','margin','toothed','shape','ovate');
lantana = imread("C:\Users\user\Desktop\group 2\lantana.jpg");
figure;
imshow(lantana);