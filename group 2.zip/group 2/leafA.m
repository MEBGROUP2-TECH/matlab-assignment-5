leaves = struct('number','1','name','mango leaf','leaftype','simple','leafvenation','pinatereticulate','margin','entire margin','shape','elliptical', 'texture','leathery and strong');
mangoleaf = imread("C:\Users\user\Desktop\group 2\mango leaf.jpg");
figure;
imshow(mangoleaf)