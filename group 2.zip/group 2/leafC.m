leaves = struct('number','3','name','elephant grass','leaftype','simple','venation','parallel','texture','fibrous','margin','smooth','shape','linear');
Eleohant = imread("C:\Users\user\Desktop\group 2\elephant grass..jpg");
figure;
imshow(Eleohant);