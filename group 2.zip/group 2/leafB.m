leaves = struct('number','2','name','paw paw leaf','leaftype','simple','texture','palinate','margin','robed','shape','brodly ovate');
pawpawleaf =imread("C:\Users\user\Desktop\group 2\pawpaw leaf.jpg");
figure;
imshow(pawpawleaf);
