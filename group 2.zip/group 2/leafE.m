leaves = struct('number','5','name','wax pivet','leaftype','compound','venationtype','pinnate reticulate','texture','glossy','margin','entire smooth','shape','pinnate compound');
wax = imread("C:\Users\user\Desktop\group 2\wax pivet.jpg");
figure;
imshow(wax);
   